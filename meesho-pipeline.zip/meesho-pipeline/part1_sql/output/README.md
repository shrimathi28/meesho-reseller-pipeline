# Part 1 — Query Output Notes

## Why `COUNT(*)` cannot be used to detect a zero-match LEFT JOIN row

`resellers_no_orders.csv` shows that `RS024` ("Ahmedabad Reseller 6", West) is the
only reseller with no matching rows in `orders`.

`count_star_vs_count_col.csv` demonstrates why you can't test for that with
`COUNT(*)`:

| reseller_id | star_count | order_id_count |
|---|---|---|
| RS024 | 1 | 0 |

When a `LEFT JOIN` finds no matching row on the right-hand table, SQL does not
drop the left-hand row — it keeps it and fills every right-hand column with
`NULL`. So the grouped result for RS024 still contains exactly **one row**
(all-NULL on the `orders` side). `COUNT(*)` counts rows regardless of their
content, so it counts that phantom all-NULL row and reports `1` — which looks
like "one order" even though there are zero. `COUNT(order_id)` counts only
non-NULL values of the named column, so it correctly reports `0`.

**Takeaway:** to detect "this reseller has zero orders" after a LEFT JOIN,
always test `COUNT(<child_table_column>) = 0` (or `IS NULL` on a
not-nullable child column), never `COUNT(*) = 0` — the latter will never be
true for a LEFT JOIN row, even when there's no real match.
