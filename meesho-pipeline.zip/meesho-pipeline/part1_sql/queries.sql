-- Part 1 — SQL Business Query Engine
-- Run against data/meesho_reseller.db
-- Usage: sqlite3 data/meesho_reseller.db < part1_sql/queries.sql

-- ============================================================
-- Q1. Monthly revenue by category
-- Feeds Part 2 and Part 4 directly. Column names must stay exactly
-- month,category,revenue,n_orders.
-- ============================================================
SELECT
    month,
    category,
    ROUND(SUM(quantity * unit_price), 2) AS revenue,
    COUNT(*) AS n_orders
FROM orders
GROUP BY month, category
ORDER BY
    CASE month WHEN 'April' THEN 1 WHEN 'May' THEN 2 WHEN 'June' THEN 3 END,
    category;

-- ============================================================
-- Q2. Region-wise total revenue and order count
-- ============================================================
SELECT
    r.region,
    ROUND(SUM(o.quantity * o.unit_price), 2) AS total_revenue,
    COUNT(*) AS n_orders
FROM orders o
JOIN resellers r ON o.reseller_id = r.reseller_id
GROUP BY r.region
ORDER BY total_revenue DESC;

-- ============================================================
-- Q3. Top resellers by total spend (> 50000), top 5
-- ============================================================
SELECT
    o.reseller_id,
    r.reseller_name,
    ROUND(SUM(o.quantity * o.unit_price), 2) AS total_spend
FROM orders o
JOIN resellers r ON o.reseller_id = r.reseller_id
GROUP BY o.reseller_id, r.reseller_name
HAVING total_spend > 50000
ORDER BY total_spend DESC
LIMIT 5;

-- ============================================================
-- Q4a. Resellers who have never placed an order
-- LEFT JOIN resellers -> orders, keep only rows where the join found no match.
-- ============================================================
SELECT
    r.reseller_id,
    r.reseller_name,
    r.region
FROM resellers r
LEFT JOIN orders o ON r.reseller_id = o.reseller_id
WHERE o.order_id IS NULL;

-- Q4b. Why COUNT(*) is the wrong way to detect the zero-match case.
-- For the unmatched reseller, the LEFT JOIN still produces exactly one row
-- (all order_ columns NULL), so COUNT(*) counts that phantom row as 1.
-- COUNT(order_id) correctly counts 0, because COUNT(column) skips NULLs
-- while COUNT(*) counts rows regardless of NULL content.
SELECT
    r.reseller_id,
    COUNT(*)         AS star_count,      -- counts the single NULL-order row -> 1 (wrong signal)
    COUNT(o.order_id) AS order_id_count  -- counts non-NULL order_id values -> 0 (correct signal)
FROM resellers r
LEFT JOIN orders o ON r.reseller_id = o.reseller_id
WHERE r.reseller_id = 'RS024'
GROUP BY r.reseller_id;

-- ============================================================
-- Q5. Average Order Value (AOV) for June, Delivered orders only
-- ============================================================
SELECT
    ROUND(SUM(quantity * unit_price) * 1.0 / COUNT(*), 2) AS aov_june_delivered
FROM orders
WHERE month = 'June' AND status = 'Delivered';
