# Part 4 — Agent Specification: Reseller Growth Monitoring Agent

## Goal

Keep Meesho category managers informed of any category whose month-on-month
revenue moves beyond the 8% threshold, with a human approving every message
before it goes out.

## Tools

The agent calls only these concrete, already-tested functions — it never
re-implements their logic:

- `growth_engine.validate_feed(csv_path)` (Part 2) — input guardrail over
  the monthly revenue feed.
- `growth_engine.mom_growth(previous, current)` (Part 2) — computes MoM
  growth percentage.
- `growth_engine.is_flagged(mom_pct, threshold=8.0)` (Part 2) — classifies
  a category as `"flagged"`, `"not_flagged"`, or `"escalate_exact_boundary"`.
- Part 3's prompt-pack template-fill function (`draft_message` in
  `mock_agent_runner.py`) — turns a flagged category's verified numbers
  into a Context → Insight → Implication narrative, filling only the
  placeholders listed in `prompt_pack.md`.

## Memory / State

Between runs, the agent must remember **the previous month's revenue per
category**, so the next run's `mom_growth` call has something to compare
against. In this mock runner that state is supplied explicitly as the
`previous_month_csv` argument to `run()` (i.e. the state is externalized as
a file rather than kept in agent memory, which keeps the mock deterministic
and testable) — a production version would persist this as a small
key-value store keyed by `(month, category) -> revenue`.

## Planner

See the numbered subtask list in §4.2 below — that ordered sequence *is*
the Planner.

## Feedback Loop

No drafted message is ever transmitted automatically. Every entry in
`flagged_categories` with `drafted: true` is held with
`action_taken: "drafted_and_held_for_approval"` in the JSON output; a human
category manager reviews and approves it before it is considered "sent."
This is simulated as a flag in the runner's output only — no actual
email/Slack/SMTP integration exists or is required.

## Guardrails

- **Input guardrail:** `validate_feed` must return `(True, [])` before any
  other subtask runs. If it fails, the run is a Hard Stop (see below) — no
  MoM computation is attempted on unvalidated data.
- **Action guardrail:** no message is ever auto-sent. Every drafted message
  is only ever drafted and held for human approval; there is no code path
  that transmits a message.
- **Output guardrail:** every number that appears inside a drafted message
  must trace back to a Part 1/Part 2 value (`previous_revenue`,
  `current_revenue`, or `mom_pct` for that category) — the draft function
  never invents, estimates, or interpolates a figure.

## Success and error stopping conditions

- **Success:** the run produces drafts for the flagged categories within
  the top-3-by-magnitude cap (or correctly produces zero drafts if nothing
  crossed the threshold that month), and every number in every draft is
  traceable to Part 1/Part 2 output.
- **Error (Hard Stop):** `validate_feed` returns `False`. The run stops
  immediately, surfaces the validation errors in `validation_errors`, sets
  `action_taken: "hard_stop"`, and leaves `flagged_categories` and
  `suppressed_categories` empty. This is a hard stop, not a silent skip —
  the run must make it obvious that no numbers were trusted.

## Given-When-Then specs (agent-level, reusing Part 2 §"Required tests")

1. **GIVEN** April→May Ethnic Wear revenue moves from 104520.77 to
   185107.61, **WHEN** the agent computes MoM growth and classifies it,
   **THEN** the agent records mom_pct = 77.1 and classification =
   `"flagged"` for Ethnic Wear in that run's `flagged_categories`.
2. **GIVEN** May→June Beauty & Personal Care revenue moves from 35542.11 to
   37559.07, **WHEN** the agent computes MoM growth and classifies it,
   **THEN** the agent records mom_pct = 5.67, classification =
   `"not_flagged"`, and Beauty & Personal Care appears in neither
   `flagged_categories` nor `suppressed_categories` for that run.
3. **GIVEN** a synthetic category pair previous=100000, current=108000
   (exactly on the 8% boundary), **WHEN** the agent computes MoM growth and
   classifies it, **THEN** the agent records mom_pct = 8.0, classification
   = `"escalate_exact_boundary"`, and logs that category into
   `escalated_categories` without drafting a message for it.
4. **GIVEN** the corrupted feed fixture (3 validation errors: one negative
   revenue, one missing category, one missing revenue), **WHEN** the agent
   runs `validate_feed` on it as the current-month feed, **THEN** the agent
   Hard Stops with `validation_status = "invalid"`,
   `action_taken = "hard_stop"`, the 3 error strings surfaced verbatim in
   `validation_errors`, and both `flagged_categories` and
   `suppressed_categories` left empty.

## 4.2 Ordered subtasks (Planner)

1. Load the monthly revenue feed and run `validate_feed`.
2. If invalid, Hard Stop and report the validation errors.
3. If valid, compute `mom_growth` for every category against the previous
   month.
4. Run `is_flagged` on every category's MoM percentage.
5. Sort flagged categories by `abs(mom_pct)` descending.
6. Draft a message (via Part 3's template) for at most the **top 3** by
   magnitude — this cap exists specifically to prevent the
   notification-flooding failure mode of drafting (and eventually sending)
   one message per flagged item with no limit.
7. Log any remaining flagged categories beyond the cap as
   `"suppressed, review manually"` — do not draft a message for them.
7b. Separately, log any category whose `is_flagged` result is
   `"escalate_exact_boundary"` into `escalated_categories`, without
   drafting a message for it. An exact-boundary category is neither
   flagged nor not_flagged, so it must never be silently dropped from both
   lists or mistaken for either one.
8. Emit one structured JSON object per run (schema in §4.3).

## 4.3 Structured JSON output schema

Every run (success or Hard Stop) emits exactly these top-level keys:

```json
{
  "run_month": "May",
  "validation_status": "valid",
  "validation_errors": [],
  "flagged_categories": [
    {
      "category": "Ethnic Wear",
      "mom_pct": 77.1,
      "previous_revenue": 104520.77,
      "current_revenue": 185107.61,
      "drafted": true,
      "message": "..."
    }
  ],
  "suppressed_categories": ["Beauty & Personal Care", "Home & Kitchen"],
  "escalated_categories": [],
  "action_taken": "drafted_and_held_for_approval"
}
```
