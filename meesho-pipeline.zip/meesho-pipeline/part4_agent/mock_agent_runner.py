"""
Part 4 — Mock Agent Runner.

Ties Parts 1-3 together into one guarded, repeatable pipeline. Executes
the 8 subtasks from agent_spec.md §4.2, using Part 2's growth_engine
functions unmodified and a Part-3-style template-fill for drafting.

No network call, no API key, no message-sending integration anywhere in
this module — drafting and holding for human approval is the entire scope.
"""

import csv
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "part2_engine"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from growth_engine import validate_feed, mom_growth, is_flagged  # noqa: E402

TOP_N_CAP = 3
THRESHOLD = 8.0


def _load_revenue_by_category(csv_path: str) -> dict:
    """month,category,revenue,n_orders -> {category: revenue} (assumes single month per file)."""
    revenue = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            revenue[row["category"]] = float(row["revenue"])
    return revenue


def draft_message(category: str, prev_month: str, month: str,
                   previous_revenue: float, current_revenue: float, mom_pct: float) -> str:
    """
    Part 3 prompt-pack template-fill (deterministic, fully offline — no
    LLM call). Every number in this message must trace back to the
    arguments supplied, per the Output guardrail in agent_spec.md.
    """
    direction = "up" if mom_pct > 0 else "down"
    return (
        f"Context: {category} category revenue, {prev_month} vs {month}.\n"
        f"Insight (FACT): {category} revenue moved from INR {previous_revenue} "
        f"in {prev_month} to INR {current_revenue} in {month}, a {mom_pct}% "
        f"Month-on-Month change ({direction}), beyond the {THRESHOLD}% flag threshold.\n"
        f"Implication: Review the {category} order-level breakdown by region and "
        f"reseller for {prev_month}->{month} to confirm the driver before acting "
        f"on this change."
    )


def run(month: str, previous_month_csv: str, current_month_csv: str,
        prev_month_label: str = None) -> dict:
    """
    Executes subtasks 1-8 from agent_spec.md §4.2.

    month: label for the current run's month (e.g. "May")
    previous_month_csv: Part 1-style monthly_category_revenue.csv slice for the prior month
    current_month_csv: Part 1-style monthly_category_revenue.csv slice for the current month
    prev_month_label: label for the prior month (e.g. "April"); inferred if omitted
    """
    # Subtask 1: load current-month feed and validate it (this is the feed being
    # acted on this run; the guardrail per agent_spec.md guards the current feed).
    is_valid, errors = validate_feed(current_month_csv)

    if not is_valid:
        # Subtask 2: Hard Stop on invalid input.
        return {
            "run_month": month,
            "validation_status": "invalid",
            "validation_errors": errors,
            "flagged_categories": [],
            "suppressed_categories": [],
            "escalated_categories": [],
            "action_taken": "hard_stop",
        }

    # Also validate the previous-month feed used for comparison, for the same
    # reason: no MoM computation is trusted unless both sides are clean.
    prev_valid, prev_errors = validate_feed(previous_month_csv)
    if not prev_valid:
        return {
            "run_month": month,
            "validation_status": "invalid",
            "validation_errors": prev_errors,
            "flagged_categories": [],
            "suppressed_categories": [],
            "escalated_categories": [],
            "action_taken": "hard_stop",
        }

    previous_revenue_map = _load_revenue_by_category(previous_month_csv)
    current_revenue_map = _load_revenue_by_category(current_month_csv)

    if prev_month_label is None:
        prev_month_label = "previous month"

    # Subtask 3 & 4: compute mom_growth and is_flagged for every category.
    evaluated = []
    for category, current_revenue in current_revenue_map.items():
        previous_revenue = previous_revenue_map.get(category)
        if previous_revenue is None:
            continue  # category absent from prior month; nothing to compare
        pct = mom_growth(previous_revenue, current_revenue)
        status = is_flagged(pct, threshold=THRESHOLD)
        evaluated.append({
            "category": category,
            "mom_pct": pct,
            "previous_revenue": previous_revenue,
            "current_revenue": current_revenue,
            "status": status,
        })

    flagged = [e for e in evaluated if e["status"] == "flagged"]
    escalated = [e for e in evaluated if e["status"] == "escalate_exact_boundary"]

    # Subtask 5: sort flagged categories by abs(mom_pct) descending.
    flagged.sort(key=lambda e: abs(e["mom_pct"]), reverse=True)

    # Subtask 6: draft for at most the top 3 by magnitude.
    top = flagged[:TOP_N_CAP]
    rest = flagged[TOP_N_CAP:]

    flagged_categories_out = []
    for e in top:
        message = draft_message(
            e["category"], prev_month_label, month,
            e["previous_revenue"], e["current_revenue"], e["mom_pct"],
        )
        flagged_categories_out.append({
            "category": e["category"],
            "mom_pct": e["mom_pct"],
            "previous_revenue": e["previous_revenue"],
            "current_revenue": e["current_revenue"],
            "drafted": True,
            "message": message,
        })

    # Subtask 7: log the rest as suppressed, no message drafted.
    suppressed_categories_out = [e["category"] for e in rest]

    # Subtask 7b: log exact-boundary categories separately.
    escalated_categories_out = [e["category"] for e in escalated]

    # Subtask 8: emit the structured JSON object.
    return {
        "run_month": month,
        "validation_status": "valid",
        "validation_errors": [],
        "flagged_categories": flagged_categories_out,
        "suppressed_categories": suppressed_categories_out,
        "escalated_categories": escalated_categories_out,
        "action_taken": "drafted_and_held_for_approval",
    }


def _write_month_slice(full_csv: str, month: str, out_path: str) -> None:
    """Helper: extract one month's rows from monthly_category_revenue.csv."""
    with open(full_csv, newline="") as f:
        rows = [r for r in csv.DictReader(f) if r["month"] == month]
    with open(out_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["month", "category", "revenue", "n_orders"])
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    base = os.path.dirname(os.path.abspath(__file__))
    full_csv = os.path.join(base, "..", "part1_sql", "output", "monthly_category_revenue.csv")
    tmp_dir = os.path.join(base, "_tmp_month_slices")
    os.makedirs(tmp_dir, exist_ok=True)

    april_csv = os.path.join(tmp_dir, "april.csv")
    may_csv = os.path.join(tmp_dir, "may.csv")
    june_csv = os.path.join(tmp_dir, "june.csv")
    _write_month_slice(full_csv, "April", april_csv)
    _write_month_slice(full_csv, "May", may_csv)
    _write_month_slice(full_csv, "June", june_csv)

    print("=" * 60)
    print("SCENARIO 1: May run (April -> May)")
    print("=" * 60)
    result_may = run("May", april_csv, may_csv, prev_month_label="April")
    print(json.dumps(result_may, indent=2))

    print("\n" + "=" * 60)
    print("SCENARIO 2: June run (May -> June)")
    print("=" * 60)
    result_june = run("June", may_csv, june_csv, prev_month_label="May")
    print(json.dumps(result_june, indent=2))

    print("\n" + "=" * 60)
    print("SCENARIO 3: Hard Stop (corrupted feed as current month)")
    print("=" * 60)
    corrupted_csv = os.path.join(base, "..", "part2_engine", "fixtures", "corrupted_feed.csv")
    result_bad = run("July", june_csv, corrupted_csv, prev_month_label="June")
    print(json.dumps(result_bad, indent=2))
