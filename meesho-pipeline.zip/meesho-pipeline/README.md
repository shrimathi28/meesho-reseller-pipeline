# Meesho Reseller Growth & Alert Intelligence Pipeline

A small, working, end-to-end reseller growth-monitoring pipeline: SQL layer
→ Python growth/guardrail engine → offline narrative layer → agent
spec + mock runner, exactly as required by the project brief.

**Zero API keys / zero paid services required anywhere in this pipeline.**
Every "AI narrative" step is a deterministic, fully offline template-fill
function (see `part3_narrative/prompt_pack.md` and
`draft_message()` in `part4_agent/mock_agent_runner.py`) — no real LLM call
is made or needed to satisfy any acceptance criterion.

## Requirements

Python 3.9+ (uses `tuple[bool, list[str]]` style type hints) and the
standard library only — no third-party packages are required to run any
Part. (`pytest` is optional; every test file also runs standalone with
`python3 <file>.py`.)

## How to run, in order

### 1. Regenerate the dataset

```bash
python3 data/generate_dataset.py
```

This is seeded (`random.Random(42)`) and deterministic — it always
produces `data/resellers.csv` (24 rows), `data/orders.csv` (900 rows: 300
each for April/May/June 2026), and `data/meesho_reseller.db` (SQLite,
same data in `resellers` and `orders` tables). Console output confirms the
zero-order reseller is `RS024`.

### 2. Part 1 — SQL Business Query Engine

```bash
sqlite3 data/meesho_reseller.db < part1_sql/queries.sql
```

or run the equivalent Python export script that writes each query's result
to `part1_sql/output/*.csv` (this repo's `output/` folder already contains
the generated CSVs, matching the brief's acceptance numbers exactly:
grand total revenue INR 1,262,066.92; RS024 is the only zero-order
reseller; AOV for June Delivered = INR 1,267.69). See
`part1_sql/output/README.md` for the `COUNT(*)` vs `COUNT(order_id)`
explanation for the zero-match LEFT JOIN case.

**Output → feeds Part 2 and Part 4:**
`part1_sql/output/monthly_category_revenue.csv` (columns:
`month,category,revenue,n_orders`) is consumed directly downstream — its
column names must not change.

### 3. Part 2 — Python Guardrail & Growth-Detection Engine

```bash
python3 part2_engine/test_growth_engine.py
# or, if pytest is installed:
pytest part2_engine/test_growth_engine.py -v
```

Implements and tests `mom_growth`, `is_flagged`, and `validate_feed` in
`part2_engine/growth_engine.py`. All 7 tests pass, including the 4 required
Given-When-Then cases and the full April→May / May→June MoM tables from
the brief.

**Output → reused unmodified by Part 4.**

### 4. Part 3 — Reliable AI Narrative & Prompt-Pack Report

- `part3_narrative/prompt_pack.md` — the reusable Trigger / Input list /
  Prompt / Checklist template used to turn a flagged category into a
  stakeholder update.
- `part3_narrative/narrative_report.md` — worked May Ethnic Wear (+77.1%)
  and June Ethnic Wear (-58.74%) narratives, self-scored against the
  4-criterion checklist, plus the 3-question chart-choice justification
  (text only, no images).
- `part3_narrative/masking.py` — `alias_for()` and
  `assert_no_raw_names_leak()`, run standalone with:

  ```bash
  python3 part3_narrative/masking.py
  ```

**Output → the template-fill logic here is reused by Part 4's `draft_message()`.**

### 5. Part 4 — Agentic Workflow Spec + Mock Agent Runner

- `part4_agent/agent_spec.md` — Goal / Tools / Memory / Planner / Feedback
  Loop, the three guardrails, success/error stopping conditions, and the 4
  agent-level Given-When-Then specs (reused from Part 2).
- `part4_agent/mock_agent_runner.py` — `run(month, previous_month_csv,
  current_month_csv)`, implementing subtasks 1-8 with Part 2's
  `growth_engine` functions imported unmodified.

```bash
python3 part4_agent/mock_agent_runner.py
```

Runs all three required scenarios (May, June, and a Hard Stop against the
corrupted feed) and prints each run's structured JSON object. Verified
output matches the brief exactly:

- **May run:** 3 drafted (Ethnic Wear +77.1%, Western Wear -23.6%, Kids
  Wear -23.48%), 2 suppressed (Beauty & Personal Care, Home & Kitchen).
- **June run:** 3 drafted (Ethnic Wear -58.74%, Home & Kitchen +42.59%,
  Kids Wear +23.9%), 1 suppressed (Western Wear +11.97%). Beauty &
  Personal Care (+5.67%) appears in neither list.
- **Hard Stop run:** `validation_status: "invalid"`,
  `action_taken: "hard_stop"`, the exact 3 corrupted-feed error strings
  surfaced, both `flagged_categories` and `suppressed_categories` empty.
- `escalated_categories` is `[]` in all three real scenarios (no
  April/May/June transition lands exactly on the 8.0% boundary); the
  synthetic 8.0%-boundary case is covered separately in Part 2's tests.

## How the Parts connect

- **Part 1 → Part 2** mirrors the "compute real numbers via SQL first,
  then hand off" order of operations: Part 2 never recomputes revenue —
  it only validates and classifies the CSV that Part 1's SQL already
  produced.
- **Part 2 → Part 3** supplies the verified `mom_pct` / revenue figures
  that the prompt pack is only ever allowed to restate, never invent.
- **Part 1 + Part 2 + Part 3 → Part 4** mirrors an
  **Intake → Summary → Report Draft → Validate** reporting flow: Intake
  (subtask 1, `validate_feed` on Part 1's output) → Summary (subtasks 3-5,
  `mom_growth` + `is_flagged` + sort) → Report Draft (subtask 6, Part 3's
  template-fill, capped at top 3) → Validate/Hold (subtasks 7-8, suppress
  the rest, log boundary cases separately, emit JSON and hold every draft
  for human approval rather than auto-sending).

## Reference material consulted

Only the official Python standard-library docs (`csv`, `sqlite3`, `random`,
`json`) were referenced while implementing each Part, per the academic
integrity note in the brief.

## Repository layout

```
data/generate_dataset.py        data/resellers.csv        data/orders.csv
data/meesho_reseller.db
part1_sql/queries.sql           part1_sql/output/*.csv    part1_sql/output/README.md
part2_engine/growth_engine.py   part2_engine/test_growth_engine.py
part2_engine/fixtures/*.csv
part3_narrative/prompt_pack.md  part3_narrative/narrative_report.md
part3_narrative/masking.py
part4_agent/agent_spec.md       part4_agent/mock_agent_runner.py
README.md
```
