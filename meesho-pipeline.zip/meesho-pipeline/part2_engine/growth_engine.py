"""
Part 2 — Python Guardrail & Growth-Detection Engine

Turns "significant change" into a numeric, testable rule, and validates
the monthly_category_revenue.csv feed that Part 1 produces before any
downstream code (Part 4's agent) is allowed to act on it.
"""

import csv


def mom_growth(previous: float, current: float) -> float:
    """Month-on-Month growth percentage, rounded to 2 decimals."""
    return round((current - previous) / previous * 100, 2)


def is_flagged(mom_pct: float, threshold: float = 8.0) -> str:
    """
    Classify a MoM growth percentage against a threshold.

    Returns one of three strings (never a bare boolean):
      - "flagged"                 if abs(mom_pct) > threshold
      - "not_flagged"             if abs(mom_pct) < threshold
      - "escalate_exact_boundary" if abs(mom_pct) == threshold exactly

    An exact-boundary case is neither auto-approved nor auto-rejected —
    it is always held for human review.
    """
    magnitude = abs(mom_pct)
    if magnitude == threshold:
        return "escalate_exact_boundary"
    elif magnitude > threshold:
        return "flagged"
    else:
        return "not_flagged"


def validate_feed(csv_path: str) -> tuple[bool, list[str]]:
    """
    Input guardrail over a month,category,revenue,n_orders CSV.

    Checks every data row (line 2 onward, 1-indexed with the header as
    line 1) for:
      - blank category
      - blank revenue
      - revenue present but not parseable as a float
      - revenue parseable but negative

    Returns (True, []) if there are zero errors, else (False, errors).
    """
    errors: list[str] = []

    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for line_offset, row in enumerate(reader, start=2):  # header is line 1
            month = row.get("month", "")
            category = row.get("category", "")
            revenue = row.get("revenue", "")

            if not category or not category.strip():
                errors.append(f"line {line_offset}: missing category (month={month})")
                continue

            if not revenue or not revenue.strip():
                errors.append(f"line {line_offset}: missing revenue (category={category})")
                continue

            try:
                revenue_val = float(revenue)
            except ValueError:
                errors.append(f"line {line_offset}: revenue not numeric: {revenue!r}")
                continue

            if revenue_val < 0:
                errors.append(
                    f"line {line_offset}: negative revenue ({revenue_val}) for category={category}"
                )

    return (True, []) if not errors else (False, errors)
