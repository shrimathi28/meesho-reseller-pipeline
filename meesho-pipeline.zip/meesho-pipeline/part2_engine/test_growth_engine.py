"""
Given-When-Then unit tests for Part 2's growth_engine.

Run with:  pytest part2_engine/test_growth_engine.py
or:        python3 part2_engine/test_growth_engine.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from growth_engine import mom_growth, is_flagged, validate_feed

FIXTURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


def test_case_1_may_ethnic_wear_flagged():
    # GIVEN April->May Ethnic Wear revenue moves from 104520.77 to 185107.61
    previous, current = 104520.77, 185107.61
    # WHEN mom_growth then is_flagged run on it
    pct = mom_growth(previous, current)
    result = is_flagged(pct)
    # THEN mom_growth returns 77.1 and is_flagged returns "flagged"
    assert pct == 77.1, f"expected 77.1, got {pct}"
    assert result == "flagged", f"expected 'flagged', got {result}"


def test_case_2_june_beauty_not_flagged():
    # GIVEN May->June Beauty & Personal Care revenue moves from 35542.11 to 37559.07
    previous, current = 35542.11, 37559.07
    # WHEN evaluated
    pct = mom_growth(previous, current)
    result = is_flagged(pct)
    # THEN mom_growth returns 5.67 and is_flagged returns "not_flagged"
    assert pct == 5.67, f"expected 5.67, got {pct}"
    assert result == "not_flagged", f"expected 'not_flagged', got {result}"


def test_case_3_exact_boundary_escalates():
    # GIVEN a synthetic pair previous=100000, current=108000 (exactly on the 8% boundary)
    previous, current = 100000, 108000
    # WHEN evaluated
    pct = mom_growth(previous, current)
    result = is_flagged(pct)
    # THEN mom_growth returns exactly 8.0 and is_flagged returns "escalate_exact_boundary"
    assert pct == 8.0, f"expected 8.0, got {pct}"
    assert result == "escalate_exact_boundary", f"expected 'escalate_exact_boundary', got {result}"
    assert result != "flagged"
    assert result != "not_flagged"


def test_case_4_corrupted_feed_validation():
    # GIVEN the corrupted feed fixture
    path = os.path.join(FIXTURES_DIR, "corrupted_feed.csv")
    # WHEN validate_feed runs on it
    ok, errors = validate_feed(path)
    # THEN it returns (False, errors) with exactly 3 entries in this order
    assert ok is False
    assert len(errors) == 3, f"expected 3 errors, got {len(errors)}: {errors}"
    assert errors[0] == "line 3: negative revenue (-4200.0) for category=Western Wear"
    assert errors[1] == "line 4: missing category (month=July)"
    assert errors[2] == "line 6: missing revenue (category=Home & Kitchen)"


def test_validated_feed_passes_clean():
    # The real Part 1 output must pass validate_feed with zero errors.
    path = os.path.join(FIXTURES_DIR, "monthly_category_revenue.csv")
    ok, errors = validate_feed(path)
    assert ok is True
    assert errors == []


# --- Full MoM tables referenced in the brief (extra coverage) ---

def test_may_vs_april_full_table():
    expected = {
        "Ethnic Wear": (77.1, "flagged"),
        "Western Wear": (-23.6, "flagged"),
        "Kids Wear": (-23.48, "flagged"),
        "Home & Kitchen": (-9.25, "flagged"),
        "Beauty & Personal Care": (-12.75, "flagged"),
    }
    april = {
        "Ethnic Wear": 104520.77, "Western Wear": 113866.15, "Kids Wear": 59847.27,
        "Home & Kitchen": 100446.23, "Beauty & Personal Care": 40737.01,
    }
    may = {
        "Ethnic Wear": 185107.61, "Western Wear": 86998.18, "Kids Wear": 45793.78,
        "Home & Kitchen": 91152.57, "Beauty & Personal Care": 35542.11,
    }
    for cat, (exp_pct, exp_flag) in expected.items():
        pct = mom_growth(april[cat], may[cat])
        assert pct == exp_pct, f"{cat}: expected {exp_pct}, got {pct}"
        assert is_flagged(pct) == exp_flag


def test_june_vs_may_full_table():
    expected = {
        "Ethnic Wear": (-58.74, "flagged"),
        "Western Wear": (11.97, "flagged"),
        "Kids Wear": (23.9, "flagged"),
        "Home & Kitchen": (42.59, "flagged"),
        "Beauty & Personal Care": (5.67, "not_flagged"),
    }
    may = {
        "Ethnic Wear": 185107.61, "Western Wear": 86998.18, "Kids Wear": 45793.78,
        "Home & Kitchen": 91152.57, "Beauty & Personal Care": 35542.11,
    }
    june = {
        "Ethnic Wear": 76371.53, "Western Wear": 97415.64, "Kids Wear": 56737.78,
        "Home & Kitchen": 129971.22, "Beauty & Personal Care": 37559.07,
    }
    for cat, (exp_pct, exp_flag) in expected.items():
        pct = mom_growth(may[cat], june[cat])
        assert pct == exp_pct, f"{cat}: expected {exp_pct}, got {pct}"
        assert is_flagged(pct) == exp_flag


if __name__ == "__main__":
    tests = [
        test_case_1_may_ethnic_wear_flagged,
        test_case_2_june_beauty_not_flagged,
        test_case_3_exact_boundary_escalates,
        test_case_4_corrupted_feed_validation,
        test_validated_feed_passes_clean,
        test_may_vs_april_full_table,
        test_june_vs_may_full_table,
    ]
    passed = 0
    for t in tests:
        t()
        print(f"PASS: {t.__name__}")
        passed += 1
    print(f"\n{passed}/{len(tests)} tests passed.")
