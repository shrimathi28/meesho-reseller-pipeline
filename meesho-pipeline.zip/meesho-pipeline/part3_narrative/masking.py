"""
Part 3.4 — Masking policy.

Any narrative that could reach an external-facing summary must never
expose a raw reseller name. This module provides the alias function and
a guard that asserts no raw name leaked into a piece of narrative text.
"""


def alias_for(reseller_id: str) -> str:
    """
    Turn a reseller_id like 'RS019' into a coded alias like 'ALIAS-19'.
    'RS006' -> 'ALIAS-06' (keeps the original zero-padding/digit count).
    """
    return f"ALIAS-{reseller_id[3:]}"


def assert_no_raw_names_leak(text: str, reseller_names: list[str]) -> bool:
    """
    Returns False if any raw reseller_name string appears verbatim inside
    text. Returns True only if none of the supplied names leak.
    """
    for name in reseller_names:
        if name in text:
            return False
    return True


if __name__ == "__main__":
    # Sanity checks matching Part 3 acceptance criteria
    assert alias_for("RS019") == "ALIAS-19"
    assert alias_for("RS006") == "ALIAS-06"

    top_reseller_names = [
        "Mumbai Reseller 1", "Mumbai Reseller 4", "Hyderabad Reseller 6",
        "Lucknow Reseller 6", "Jaipur Reseller 5",
    ]

    safe_narrative = (
        f"The top-performing reseller this period was {alias_for('RS019')} "
        f"in the West region, with total spend of INR 75295.09. The next "
        f"highest was {alias_for('RS022')}, also West, at INR 73882.33."
    )
    assert assert_no_raw_names_leak(safe_narrative, top_reseller_names) is True

    # Negative case: a version that still names the reseller directly
    leaky_narrative = (
        "The top-performing reseller this period was Mumbai Reseller 1 "
        "in the West region, with total spend of INR 75295.09."
    )
    assert assert_no_raw_names_leak(leaky_narrative, top_reseller_names) is False

    print("All masking.py sanity checks passed.")
