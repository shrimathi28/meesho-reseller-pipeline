# Prompt Pack — Flagged-Category Stakeholder Update

This is the one reusable prompt used by Part 4's agent to turn a verified,
flagged category into a stakeholder-ready narrative. It is filled by a
deterministic, fully offline template-fill function
(`part3_narrative` logic reused in `part4_agent/mock_agent_runner.py`) — no
LLM API call is required anywhere in the pipeline.

## Trigger

This prompt fires whenever `is_flagged(mom_pct)` (Part 2) returns exactly
`"flagged"` for a category's month-on-month revenue change. It does **not**
fire for `"not_flagged"` or `"escalate_exact_boundary"` — the latter is
routed to human review instead of narrative drafting (see Part 4 §4.2).

## Input list

Every placeholder the prompt needs, all of which must trace back to a Part 1
or Part 2 value — nothing else may be substituted in:

- `{category}` — the flagged category name
- `{month}` — the current month being reported (e.g. "May")
- `{prev_month}` — the prior month being compared against (e.g. "April"),
  needed so the narrative can name the comparison explicitly
  (e.g. "May vs. April")
- `{previous_revenue}` — prior month's revenue for this category (INR)
- `{current_revenue}` — current month's revenue for this category (INR)
- `{mom_pct}` — the signed MoM growth percentage from `mom_growth()`

## Prompt

```
You are drafting a short internal update for a Meesho regional category
manager. Use ONLY the values supplied below — never invent, estimate, or
round a number beyond what is given, and never state a number that is not
one of the supplied placeholders.

Category: {category}
Comparison window: {prev_month} -> {month}
Previous revenue: INR {previous_revenue}
Current revenue: INR {current_revenue}
MoM change: {mom_pct}%

Write the update in exactly three labeled parts:

Context: One sentence stating what is being measured (category revenue)
and over what period ({prev_month} vs {month}).

Insight: One sentence stating the {mom_pct}% change as a labeled FACT,
using only {previous_revenue} and {current_revenue}.

Implication: One or two sentences giving a specific, actionable next step
for a regional manager (name what to check or do next — not a vague
"look into it"). If the sentence proposes a cause the data alone doesn't
prove, label it explicitly as a HYPOTHESIS.

Do not reference any reseller by raw name — use region and alias only if a
specific reseller is mentioned.
```

## Checklist

Run all of these against the drafted output before it is used or held for
approval (Part 4's Action guardrail):

1. **Number-fidelity check** — every numeric figure appearing in the draft
   matches one of the supplied placeholder values exactly (same digits); no
   number appears that cannot be traced back to `{previous_revenue}`,
   `{current_revenue}`, or `{mom_pct}`.
2. **Fact/hypothesis labeling check** — every claim in the draft is
   explicitly labeled as a FACT (directly computed from the numbers) or a
   HYPOTHESIS (a proposed cause or explanation not proven by the numbers
   alone).
3. **Actionability check** — the Implication names a concrete next step
   (a specific report to pull, a specific team to contact, a specific
   category/region to compare) rather than a vague instruction like "look
   into ethnic wear."
4. **No-raw-name check** — `assert_no_raw_names_leak()` (Part 3 §3.4)
   returns `True` on the draft; no reseller is referenced by raw
   `reseller_name`, only by region and `alias_for(reseller_id)`.
5. **Completeness check** — all three labeled sections (Context, Insight,
   Implication) are present and non-empty.
6. **Audience-fit check** — the language is plain-English and
   business-facing (no SQL, no code, no column names), suitable for a
   regional manager rather than a data engineer.
