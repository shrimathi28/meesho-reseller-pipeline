# Part 3 — Worked Narrative Report

## 3.2 Worked narratives (real numbers from Parts 1 & 2)

### May Ethnic Wear (+77.1% MoM, flagged)

**Context:** This update covers Ethnic Wear category revenue for the
April-to-May 2026 comparison window.

**Insight (FACT):** Ethnic Wear revenue rose from INR 104,520.77 in April to
INR 185,107.61 in May, a Month-on-Month increase of +77.1%, well above the
8% flag threshold.

**Implication:** Pull the April-to-May order-level breakdown for Ethnic Wear
by region and by reseller (Part 1's `top_resellers` and region queries) to
confirm whether the growth is broad-based across regions or concentrated in
one or two resellers, and check whether unit_price or order-count (or both)
drove the increase before reallocating inventory or marketing spend toward
the category. (HYPOTHESIS: the timing suggests a seasonal or promotional
effect around early-summer ethnic-wear demand, but this is not proven by
the revenue numbers alone and should be checked against any known campaign
calendar.)

**Self-score against the 4-criterion checklist:**
- **Specificity** — passes: names the exact category (Ethnic Wear), the
  exact figures (INR 104,520.77 → INR 185,107.61), the exact percentage
  (+77.1%), and the exact months (April, May).
- **Audience fit** — passes: written in plain business language (no SQL,
  no column names, no code) suitable for a regional manager, not an
  analyst.
- **Completeness** — passes: all three sections (Context, Insight,
  Implication) are present and non-empty.
- **Actionability** — passes: the Implication names a concrete next step
  (pull the region/reseller breakdown, check unit_price vs. order-count
  drivers) rather than a vague "look into ethnic wear."

### June Ethnic Wear (-58.74% MoM, flagged)

**Context:** This update covers Ethnic Wear category revenue for the
May-to-June 2026 comparison window.

**Insight (FACT):** Ethnic Wear revenue fell from INR 185,107.61 in May to
INR 76,371.53 in June, a Month-on-Month change of -58.74%, well beyond the
8% flag threshold in the negative direction.

**Implication:** Compare June's Ethnic Wear order count (52) against May's
(104) to confirm whether the drop is driven mainly by fewer orders or by
lower revenue per order, and check the June `status` breakdown for Ethnic
Wear specifically for any spike in Cancelled or Returned orders that could
partly explain the fall. (HYPOTHESIS: because May's spike and June's drop
are both large and roughly offsetting in scale, this pattern is consistent
with a one-off promotional pull-forward in May rather than a genuine
demand decline — but that requires checking the campaign calendar and
cannot be confirmed from revenue figures alone.)

**Self-score against the 4-criterion checklist:**
- **Specificity** — passes: names the exact category (Ethnic Wear), the
  exact figures (INR 185,107.61 → INR 76,371.53), the exact percentage
  (-58.74%), and the exact months (May, June).
- **Audience fit** — passes: plain business language, no SQL or code,
  written for a regional manager.
- **Completeness** — passes: Context, Insight, and Implication are all
  present.
- **Actionability** — passes: the Implication names concrete checks
  (compare order counts, inspect the status breakdown for
  cancellations/returns) rather than a vague instruction.

---

## 3.3 Chart-choice justification

**1. "Which month had the highest total revenue?"**
(April = INR 419,417.43, May = INR 444,594.25, June = INR 398,055.24)

This is a **univariate comparison across a small number of categorical
groups (3 months)**. A simple **vertical bar chart**, one bar per month, is
the right choice: with only 3 bars the "which is tallest" message reads in
well under 10 seconds, the y-axis can safely start at zero so bar heights
are directly comparable, no legend is needed since there's only one series,
and a 2D bar avoids the distorted comparisons that 3D bars introduce.

**2. "What percentage share does Ethnic Wear represent of April's total
revenue?"** (INR 104,520.77 of INR 419,417.43 = 24.92%)

This is a **part-to-whole (univariate share) question** for a single month.
A **100%-stacked single bar or a simple bar comparing the one category's
revenue against the month's total** communicates this faster and more
accurately than a pie/donut chart, because bar length is easier for a
reader to judge precisely than a wedge angle. (A single donut slice
labeled "24.92%" is an acceptable lightweight alternative for a one-off
share, but a 5-way pie across all categories would violate the "clear in
10 seconds" principle once more than 2-3 slices are shown — so this stays
as a single highlighted bar against the month total, not a multi-slice
pie.)

**3. "How do the four regions compare on total revenue?"**
(North = INR 337,125.46, South = INR 316,736.68, East = INR 275,098.45,
West = INR 333,106.33)

This is again a **univariate comparison across 4 categorical groups**
(regions), so a **horizontal or vertical bar chart**, one bar per region,
ordered by value, is the right choice for the same reasons as Question 1:
4 bars are readable in under 10 seconds, a zero-based axis keeps the
comparison honest, and a single series needs no legend. A pie chart is
avoided here too, since judging small differences between 4 similarly
sized wedges (all in the INR 275k-337k range) is harder than judging 4 bar
heights.
